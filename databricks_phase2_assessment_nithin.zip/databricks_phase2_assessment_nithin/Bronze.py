# Databricks notebook source
# %sql
# use catalog dev;
# use schema bronze;

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("catalog","dev")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

# Read all files from the datasets directory in dev.bronze.raw volume
df = spark.read.csv(f"/Volumes/{catalog}/bronze/raw/datasets/orders.csv", header=True, inferSchema=True)

# Add columns for file path and row updated time
df1 = df.withColumn("file_path", col("_metadata.file_path")).withColumn("ingested_at", current_timestamp())

# Create a table from the DataFrame
df1.write.mode("overwrite").saveAsTable(f"{catalog}.bronze.orders")

# Delta Optimize and vacuum
spark.sql(f"OPTIMIZE {catalog}.bronze.orders ZORDER BY (order_id)")
spark.sql(f"VACUUM {catalog}.bronze.orders RETAIN 48 HOURS")


# COMMAND ----------

# Read all files from the datasets directory in dev.bronze.raw volume
df = spark.read.csv(f"/Volumes/{catalog}/bronze/raw/datasets/customers.csv", header=True, inferSchema=True)

# Add columns for file path and row updated time
df1 = df.withColumn("file_path", col("_metadata.file_path")).withColumn("ingested_at", current_timestamp())

# Create a table from the DataFrame
df1.write.mode("overwrite").saveAsTable(f"{catalog}.bronze.customers")

# Delta Optimize
spark.sql(f"OPTIMIZE {catalog}.bronze.customers ZORDER BY (customer_id)")
spark.sql(f"VACUUM {catalog}.bronze.customers RETAIN 48 HOURS")

# COMMAND ----------

# Read all files from the datasets directory in dev.bronze.raw volume
df = spark.read.csv(f"/Volumes/{catalog}/bronze/raw/datasets/order_items.csv", header=True, inferSchema=True)

# Add columns for file path and row updated time
df1 = df.withColumn("file_path", col("_metadata.file_path")).withColumn("ingested_at", current_timestamp())

# Create a table from the DataFrame
df1.write.mode("overwrite").saveAsTable(f"{catalog}.bronze.order_items")

# Delta Optimize
spark.sql(f"OPTIMIZE {catalog}.bronze.order_items ZORDER BY (order_item_id)")
spark.sql(f"VACUUM {catalog}.bronze.order_items RETAIN 48 HOURS")

# COMMAND ----------

# Read all files from the datasets directory in dev.bronze.raw volume
df = spark.read.csv(f"/Volumes/{catalog}/bronze/raw/datasets/products.csv", header=True, inferSchema=True)

# Add columns for file path and row updated time
df1 = df.withColumn("file_path", col("_metadata.file_path")).withColumn("ingested_at", current_timestamp())

# Create a table from the DataFrame
df1.write.mode("overwrite").saveAsTable(f"{catalog}.bronze.products")

# Delta Optimize
spark.sql(f"OPTIMIZE {catalog}.bronze.products ZORDER BY (product_id)")
spark.sql(f"VACUUM {catalog}.bronze.products RETAIN 48 HOURS")

# COMMAND ----------

