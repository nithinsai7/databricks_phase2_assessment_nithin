# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("catalog","dev")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

# Read Silver tables — cache dimension tables (reused in every Gold table)

#For Non-Serverless compute use cache()
# silver_customers = spark.table(f"{catalog}.SILVER.customers").cache()
# silver_products  = spark.table(f"{catalog}.SILVER.products").cache()


silver_customers = spark.table(f"{catalog}.SILVER.silver_customers")
silver_products  = spark.table(f"{catalog}.SILVER.silver_products")
silver_orders    = spark.table(f"{catalog}.SILVER.silver_orders")
silver_items     = spark.table(f"{catalog}.SILVER.silver_order_items")

# COMMAND ----------

dim_customers = (
    silver_customers
    .select(
        "customer_id",
        "name",
        "city",
        "state",
        "signup_date",
        "created_at",
        "updated_at"
    )
)

(
    dim_customers.write
                 .format("delta")
                 .mode("overwrite")
                 .option("overwriteSchema", "true")
                 .saveAsTable(f"{catalog}.gold.dim_customers")
)
print(f"dim_customers: {spark.table(f"{catalog}.gold.dim_customers").count():,} rows ✅")

# COMMAND ----------

#Dim Products 
dim_products = (
    silver_products
    .select(
        col("product_id"),
        col("product_name"),
        col("category"),
        col("price").alias("current_price"),
        col("created_at"),
        col("updated_at"),
    )
)

(
    dim_products.write
                .format("delta")
                .mode("overwrite")
                .option("overwriteSchema", "true")
                .saveAsTable(f"{catalog}.gold.dim_products")
)
print(f"dim_products: {spark.table(f"{catalog}.gold.dim_products").count():,} rows ✅")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.silver.silver_order_items
# MAGIC left join dev.silver.silver_orders
# MAGIC on dev.silver.silver_order_items.order_id = dev.silver.silver_orders.order_id
# MAGIC left join dev.silver.

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE {catalog}.gold.fact_sales
USING DELTA
PARTITIONED BY (order_year, order_month)
AS
SELECT
    i.order_item_id,
    i.order_id,
    o.customer_id,
    i.product_id,
    o.order_date,
    YEAR(o.order_date) AS order_year,
    MONTH(o.order_date) AS order_month,
    c.city,
    c.state,
    p.product_name,
    p.category,
    i.quantity,
    i.price AS unit_price,
    i.quantity * i.price AS revenue,
    o.order_status
FROM {catalog}.silver.silver_order_items i
LEFT JOIN {catalog}.silver.silver_orders o
    ON i.order_id = o.order_id
LEFT JOIN {catalog}.gold.dim_customers c
    ON o.customer_id = c.customer_id
LEFT JOIN {catalog}.gold.dim_products p
    ON i.product_id = p.product_id
WHERE o.order_status != 'CANCELLED'
""")

print(f"fact_sales: {spark.table(f'{catalog}.gold.fact_sales').count():,} rows ✅")

# COMMAND ----------

# MAGIC %sql
# MAGIC select state , sum(revenue) as revenue from dev.gold.fact_sales
# MAGIC group by 1 
# MAGIC order by 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC --Top 10 products
# MAGIC select product_name , count(*) from dev.gold.fact_sales
# MAGIC group by 1 
# MAGIC order by 2 desc limit 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC select order_Date , sum(revenue) from dev.gold.fact_sales
# MAGIC group by 1
# MAGIC order by 1 desc;

# COMMAND ----------

# MAGIC %sql
# MAGIC select date_trunc('month' , order_Date) , sum(quantity * unit_price) from dev.gold.fact_sales
# MAGIC group by 1
# MAGIC order by 1 desc;

# COMMAND ----------

