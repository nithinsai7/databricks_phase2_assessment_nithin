# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("catalog","dev")

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

# Clean orders data
df = spark.read.table(f"{catalog}.bronze.orders")
df1 = df.drop("file_path","ingested_at").dropna().dropDuplicates(["order_id"])

# COMMAND ----------

# First Load
# table_name = f"{catalog}.silver.silver_orders"
# df1.write.mode("overwrite").saveAsTable(table_name)

# COMMAND ----------

table_name = f"{catalog}.silver.silver_orders"
max_created_at = spark.sql(f"SELECT MAX(created_at) AS max_created_at FROM {table_name}").collect()[0]['max_created_at']
df_new = df1.filter(col("created_at") > lit(max_created_at))
if df_new.count() > 0:
    df_new.write.mode("append").saveAsTable(table_name)

# COMMAND ----------

# Clean Customers data
df = spark.read.table(f"{catalog}.bronze.customers")
df1 = df.drop("file_path","ingested_at").dropna().dropDuplicates(["customer_id"])

# COMMAND ----------

# First Load
# table_name = f"{catalog}.silver.silver_customers"
# df1.write.mode("overwrite").saveAsTable(table_name)

# COMMAND ----------

table_name = f"{catalog}.silver.silver_customers"
max_created_at = spark.sql(f"SELECT MAX(created_at) AS max_created_at FROM {table_name}").collect()[0]['max_created_at']
df_new = df1.filter(col("created_at") > lit(max_created_at))
if df_new.count() > 0:
    df_new.write.mode("append").saveAsTable(table_name)

# COMMAND ----------

# Clean orders_items data
df = spark.read.table(f"{catalog}.bronze.order_items")
df1 = df.drop("file_path","ingested_at").dropna().dropDuplicates(["order_item_id"])

# COMMAND ----------

# First Load
# table_name = f"{catalog}.silver.silver_order_items"
# df1.write.mode("overwrite").saveAsTable(table_name)

# COMMAND ----------

table_name = f"{catalog}.silver.silver_order_items"
max_created_at = spark.sql(f"SELECT MAX(created_at) AS max_created_at FROM {table_name}").collect()[0]['max_created_at']
df_new = df1.filter(col("created_at") > lit(max_created_at))
if df_new.count() > 0:
    df_new.write.mode("append").saveAsTable(table_name)

# COMMAND ----------

# Clean orders_items data
df = spark.read.table(f"{catalog}.bronze.products")
df1 = df.drop("file_path","ingested_at").dropna().dropDuplicates(["product_id"])

# COMMAND ----------

# First Load
# table_name = f"{catalog}.silver.silver_products"
# df1.write.mode("overwrite").saveAsTable(table_name)

# COMMAND ----------

table_name = f"{catalog}.silver.silver_products"
max_created_at = spark.sql(f"SELECT MAX(created_at) AS max_created_at FROM {table_name}").collect()[0]['max_created_at']
df_new = df1.filter(col("created_at") > lit(max_created_at))
if df_new.count() > 0:
    df_new.write.mode("append").saveAsTable(table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Join orders and customers
# MAGIC create or replace table dev.silver.silver_orders_customers as
# MAGIC select order_id , c.customer_id , order_date , total_amount , order_status , o.created_at as order_created_at,
# MAGIC o.updated_at as order_updated_at , c.name as customer_name , c.city as customer_city ,
# MAGIC c.state as customer_state , c.signup_date as customer_signup_date , c.created_at as customer_created_at,
# MAGIC c.updated_at as customer_updated_at
# MAGIC from dev.silver.silver_orders o
# MAGIC left join dev.silver.silver_customers c
# MAGIC on o.customer_id = c.customer_id;

# COMMAND ----------

